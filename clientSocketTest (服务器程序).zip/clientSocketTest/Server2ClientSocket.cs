﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Sockets;
using System.Text;
using System.Threading.Tasks;

namespace clientSocketTest
{
    internal class Server2ClientSocket
    {
        public static int CLIENT_BEGIN_ID = 1;
        //public int clientID=>CLIENT_BEGIN_ID;
        public int clientID;
        public Socket s2cSocket;
        public bool isContected=>this.s2cSocket.Connected;

        public Queue<PlayerMsg> receivePlayerMsgQueue = new Queue<PlayerMsg>();

        public Server2ClientSocket(Socket socket)
        {
            this.s2cSocket = socket;
            clientID = CLIENT_BEGIN_ID;
            CLIENT_BEGIN_ID++;
        }
        //发送消息
        public void Send(string msgStr)
        {
            if(s2cSocket!=null)
            {
                try
                {
                    s2cSocket.Send(Encoding.UTF8.GetBytes(msgStr));
                }
                catch (Exception e)
                {

                    Console.WriteLine("发送消息出错："+e.Message);
                    Close();
                }
            }
            
        }   
            //发送Int
            public void SendInt(int i)
            {
                if (s2cSocket != null)
                {
                    try
                    {
                        s2cSocket.Send(BitConverter.GetBytes(i));
                    }
                    catch (Exception e)
                    {

                        Console.WriteLine("发送消息出错：" + e.Message);
                        Close();
                    }
                }
        }
            //发送PlayerMsg
            public void SendPlayerMsg(PlayerMsg playerMsg)
            {
            if (s2cSocket != null)
            {
                try
                {
                    s2cSocket.Send(playerMsg.Writing());
                }
                catch (Exception e)
                {

                    Console.WriteLine("发送消息出错：" + e.Message);
                    Close();
                }
            }
        }
        //接收消息
        public void Receive()
        {
            if (s2cSocket!=null)
            {
                try
                {
                    if(s2cSocket.Available>0)
                    {
                        //byte[] bytes=new byte[s2cSocket.Available];
                        byte[] bytes = new byte[1024*1024];
                        int receiveNum=s2cSocket.Receive(bytes);
                        Task.Run(() =>
                        {
                            if(BitConverter.ToInt32(bytes,0)==1001)
                            {
                                PlayerMsg playerMsg = new PlayerMsg();
                                playerMsg.Reading(bytes, 4);
                                receivePlayerMsgQueue.Enqueue(playerMsg);
                            }
                            else
                            {
                                string msgStr = Encoding.UTF8.GetString(bytes, 0, receiveNum);
                                Console.WriteLine("收到客户端{0}发来的消息：{1}", this.s2cSocket.RemoteEndPoint, msgStr);
                            }
                        });
                    }
                }
                catch (Exception e)
                {

                    Console.WriteLine ("接收消息出错："+e.Message);
                    Close();
                }
            }
        }
        //public void MsgHandle(byte[] bytes)
        //{

        //}
        //关闭连接
        public void Close()
        {
            if(s2cSocket!=null)
            {
                s2cSocket.Shutdown(SocketShutdown.Both);
                s2cSocket.Close();
                s2cSocket = null;
            }

        }

    }
}
