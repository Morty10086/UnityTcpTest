﻿namespace clientSocketTest
{
    internal class Program
    {
        static void Main(string[] args)
        {
            
            //Server2ClientSocket socket1 = new Server2ClientSocket();
            //Console.WriteLine(socket1.clientID);
            //Server2ClientSocket socekt2 = new Server2ClientSocket();
            //Console.WriteLine(socket1.clientID);
            //Console.WriteLine(socekt2.clientID);
            ServerSocket serverSocket = new ServerSocket();
            serverSocket.StartServer("127.0.0.1", 8080, 1024);
            while(true)
            {

            }
        }
    }
}