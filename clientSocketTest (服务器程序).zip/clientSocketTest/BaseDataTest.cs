using System.Collections;
using System.Collections.Generic;
using System.Text;


public class Test2 : BaseData
{
    public int age;
    public string name;
    public short id;
    public bool sex;
    public Test2(int age, string name, short id, bool sex)
    {
        this.age = age;
        this.name = name;
        this.id = id;
        this.sex = sex;
    }
    public Test2() { }
    public override int GetBytesNum()
    {
        byte[] strBytes = Encoding.UTF8.GetBytes(this.name);
        int strLength = strBytes.Length;
        return sizeof(int) + sizeof(int) + sizeof(short) + sizeof(bool) + strLength;
    }

    public override int Reading(byte[] bytes,int index)
    {
        age = ReadInt(bytes, ref index);
        name = ReadString(bytes, ref index);
        id = ReadShort(bytes, ref index);
        sex = ReadBool(bytes, ref index);
        return index;
    }

    public override byte[] Writing()
    {
        int index = 0;
        byte[] bytes = new byte[GetBytesNum()];
        WriteInt(bytes, age, ref index);
        WriteString(bytes, name, ref index);
        WriteShort(bytes, id, ref index);
        WriteBool(bytes, sex, ref index);
        return bytes;
    }
}

public class Test : BaseData
{
    public int age;
    public string name;
    public short id;
    public bool sex;
    public Test2 test2;
    public Test(int age,string name,short id,bool sex)
    {
        this.age = age;
        this.name = name;
        this.id = id;
        this.sex = sex;
    }
    public Test() { }
    public override int GetBytesNum()
    {
        byte[] strBytes=Encoding.UTF8.GetBytes(this.name);
        int strLength = strBytes.Length;
        return sizeof(int) + sizeof(int) + sizeof(short)+sizeof(bool)+strLength+test2.GetBytesNum();
    }

    public override int Reading(byte[] bytes,int index)
    {
        age=ReadInt(bytes, ref index);
        name=ReadString(bytes, ref index);
        id=ReadShort(bytes, ref index);
        sex=ReadBool(bytes, ref index);
        test2=ReadData<Test2>(bytes, ref index);
        return index;
    }

    public override byte[] Writing()
    {
        int index = 0;
        byte[] bytes=new byte[GetBytesNum()];
        WriteInt(bytes, age, ref index);
        WriteString(bytes, name, ref index);    
        WriteShort(bytes, id, ref index);
        WriteBool(bytes, sex, ref index);
        WriteData(bytes, test2, ref index);
        return bytes;
    }
}
public class BaseDataTest 
{
    
    void Start()
    {
        
        Test2 test2 = new Test2(2,"Test2",02,false);
        Test test = new Test(1, "Test", 01, true);
        test.test2 = test2;

        byte[] bytes=test.Writing();

        Test test99 = new Test();
        

    }

   
    void Update()
    {
        
    }
}
