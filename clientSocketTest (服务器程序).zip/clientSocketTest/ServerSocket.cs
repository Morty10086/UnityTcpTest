﻿
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Sockets;
using System.Runtime.CompilerServices;
using System.Text;
using System.Threading.Tasks;

namespace clientSocketTest
{
    internal class ServerSocket
    {
        public bool isClose;
        public Socket serverSocket;
        public Dictionary<int, Server2ClientSocket> s2cDic=new Dictionary<int, Server2ClientSocket>();

        public PlayerMsg playerMsg1 = new PlayerMsg();
        private Queue<PlayerMsg> receivePlayerMsgQueue1 = new Queue<PlayerMsg>();
        public PlayerMsg playerMsg2 = new PlayerMsg();
        private Queue<PlayerMsg> receivePlayerMsgQueue2 = new Queue<PlayerMsg>();
        public void StartServer(string ip,int point,int maxClientNum)
        {
            isClose = false;
            serverSocket=new Socket(AddressFamily.InterNetwork,SocketType.Stream, ProtocolType.Tcp);
            try
            {
                IPEndPoint ipPoint=new IPEndPoint(IPAddress.Parse(ip),point);
                serverSocket.Bind(ipPoint);
            }
            catch (Exception e)
            {
                Console.WriteLine("绑定出错" + e.Message);
            }
            serverSocket.Listen(maxClientNum);
            Console.WriteLine("服务器开启成功");
            Task.Run(() => AcceptClient());
            Task.Run(()=>ReceiveClientMsg());
        }
        //接受客户端连接
        public void AcceptClient()
        {
            while(!isClose)
            {
                Socket s2cSocket = serverSocket.Accept();
                if (s2cSocket!=null)
                {                   
                    Server2ClientSocket myS2CSocket=new Server2ClientSocket(s2cSocket);
                    //myS2CSocket.Send("欢迎连入服务器");
                    myS2CSocket.SendInt(myS2CSocket.clientID);
                    s2cDic.Add(myS2CSocket.clientID, myS2CSocket);
                }
            }
        }
        //接收客户端消息
        public void ReceiveClientMsg()
        {
            while(!isClose)
            {
                if(s2cDic.Count > 0)
                {
                    for(int i = 1; i <= 2; i++)
                    {
                        if (s2cDic.ContainsKey(i))
                        {
                            if (s2cDic[i] != null)
                            {
                                s2cDic[i].Receive();
                                if (s2cDic[i].receivePlayerMsgQueue.Count > 0)
                                {
                                    PlayerMsg playerMsg = s2cDic[i].receivePlayerMsgQueue.Dequeue();
                                    switch (playerMsg.playerID)
                                    {
                                        case 1:
                                            if (s2cDic.ContainsKey(2))
                                            {
                                                s2cDic[2].SendPlayerMsg(playerMsg);
                                                Console.WriteLine("P1发送至P2");
                                            }

                                            break;
                                        case 2:
                                            if (s2cDic.ContainsKey(1))
                                            {
                                                Console.WriteLine("P2发送至P1");
                                                s2cDic[1].SendPlayerMsg(playerMsg);
                                            }
                                            break;
                                    }
                                }
                            }
                        }
                    }
                    //foreach(Server2ClientSocket myS2CSocket in s2cDic.Values)
                    //{
                    //    if (myS2CSocket != null)
                    //    {
                    //        myS2CSocket.Receive();
                    //        if (myS2CSocket.receivePlayerMsgQueue.Count > 0)
                    //        {
                    //           PlayerMsg playerMsg=myS2CSocket.receivePlayerMsgQueue.Dequeue();
                    //            switch (playerMsg.playerID)
                    //            {
                    //                case 1:
                    //                    if (s2cDic.ContainsKey(2))
                    //                    {
                    //                        s2cDic[2].SendPlayerMsg(playerMsg);
                    //                        Console.WriteLine("P1发送至P2");
                    //                    }
                                            
                    //                    break;
                    //                case 2:
                    //                    if (s2cDic.ContainsKey(1))
                    //                    {
                    //                        Console.WriteLine("P2发送至P1");
                    //                        s2cDic[1].SendPlayerMsg(playerMsg);
                    //                    }                                           
                    //                    break;
                    //            }
                    //        }
                    //    }                      
                    //}
                }
            }
        }
        //关闭服务器
        public void CloseServer()
        {
            if (s2cDic.Count > 0)
            {
                foreach (Server2ClientSocket myS2CSocket in s2cDic.Values)
                {
                    myS2CSocket.Close();
                }
                s2cDic.Clear();
                serverSocket.Close();
                serverSocket = null;
            }
            Console.WriteLine("关闭");
        }
        //广播消息
        public void BroadcastMsg(string msgStr)
        {
            foreach(Server2ClientSocket myS2CSocket in s2cDic.Values)
            {
                myS2CSocket.Send(msgStr);
            }
        }
    }
}
